piccolo
=======

Tiny Arduino music visualizer!

A great demo of the Adafruit Microphone Amp and our Bi-Color LED backpack.

--> [Bicolor LED Square Pixel Matrix with I2C Backpack][ledMatrix]  
--> [Electret Microphone Amplifier][microphoneAmp]

Learn more about this project at http://learn.adafruit.com/piccolo

[ledMatrix]: http://adafruit.com/products/902
[microphoneAmp]: http://adafruit.com/products/1063
